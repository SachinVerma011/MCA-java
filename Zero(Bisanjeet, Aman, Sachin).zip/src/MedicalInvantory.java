import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

class Patient {
    String id, name, age, bp, sugar, disease;

    public Patient(String id, String name, String age, String bp, String sugar, String disease) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.bp = bp;
        this.sugar = sugar;
        this.disease = disease;
    }

    public String toString() {
        return id + "," + name + "," + age + "," + bp + "," + sugar + "," + disease;
    }
}

class DataHandler {
    ArrayList<Patient> patients = new ArrayList<>();
    File file = new File("patients.txt");

    public void loadData() {
        patients.clear();
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 6)
                    patients.add(new Patient(data[0], data[1], data[2], data[3], data[4], data[5]));
            }
        } catch (Exception e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }

    public void saveData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            for (Patient p : patients) {
                bw.write(p.toString());
                bw.newLine();
            }
        } catch (Exception e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    public Patient searchById(String id) {
        for (Patient p : patients) {
            if (p.id.equals(id)) return p;
        }
        return null;
    }

    public boolean deleteById(String id) {
        for (Patient p : patients) {
            if (p.id.equals(id)) {
                patients.remove(p);
                saveData();
                return true;
            }
        }
        return false;
    }
}

class LoginFrame extends Frame implements ActionListener {
    TextField userField, passField;
    Label msg;

    public LoginFrame() {
        setTitle("Medical Data Analyzer - Login");
        setSize(400, 250);
        setLayout(null);
        setBackground(new Color(220, 240, 255));

        Label userLabel = new Label("Username:");
        userLabel.setBounds(70, 70, 80, 25);
        add(userLabel);

        userField = new TextField();
        userField.setBounds(160, 70, 150, 25);
        add(userField);

        Label passLabel = new Label("Password:");
        passLabel.setBounds(70, 110, 80, 25);
        add(passLabel);

        passField = new TextField();
        passField.setEchoChar('*');
        passField.setBounds(160, 110, 150, 25);
        add(passField);

        Button loginBtn = new Button("Login");
        loginBtn.setBounds(160, 150, 70, 30);
        add(loginBtn);

        msg = new Label("");
        msg.setBounds(120, 190, 200, 25);
        add(msg);

        loginBtn.addActionListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String user = userField.getText();
        String pass = passField.getText();

        if (user.equals("Key") && pass.equals("key011")) {
            msg.setText("Login Successful!");
            dispose();
            new MainFrame();
        } else {
            msg.setText("Invalid Credentials!");
        }
    }
}

class MainFrame extends Frame implements ActionListener {
    DataHandler handler = new DataHandler();
    TextArea display;

    public MainFrame() {
        setTitle("Medical Data Analyzer");
        setSize(700, 500);
        setLayout(new BorderLayout());

        // North Panel - Buttons
        Panel topPanel = new Panel();
        topPanel.setLayout(new FlowLayout());

        String[] btnNames = {"Home", "Load Data", "Add Patient", "Search Patient", "Delete Patient", "Analyze", "Predict Disease"};
        for (String name : btnNames) {
            Button b = new Button(name);
            b.addActionListener(this);
            topPanel.add(b);
        }

        add(topPanel, BorderLayout.NORTH);


        display = new TextArea("", 20, 80, TextArea.SCROLLBARS_VERTICAL_ONLY);
        add(display, BorderLayout.CENTER);


        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        switch (cmd) {
            case "Home":
                display.setText("Welcome to the Medical Data Analyzer System!\nUse the buttons above to manage patient records.");
                display.setEditable(false);
                display.setFont(new Font("Arial", Font.BOLD, 18));


                break;

            case "Load Data":
                handler.loadData();
                display.setText("Patient Data Loaded Successfully.\n\n");
                display.setEditable(false);
                for (Patient p : handler.patients)
                    display.append(p.id + "\t" + p.name + "\t" + p.age + "\t" + p.bp + "\t" + p.sugar + "\t" + p.disease + "\n");
                break;

            case "Add Patient":
                new AddPatientFrame(handler, display);
                break;

            case "Search Patient":
                new SearchPatientFrame(handler, display);
                break;

            case "Delete Patient":
                new DeletePatientFrame(handler, display);
                break;

            case "Analyze":
                handler.loadData();
                display.setText("Automatic Health Analysis:\n\n");
                if (handler.patients.size() == 0) {
                    display.append("No patient records found.");
                    break;
                }
                int diabetes = 0, hypertension = 0, normal = 0;
                for (Patient p : handler.patients) {
                    try {
                        int bp = Integer.parseInt(p.bp.trim());
                        int sugar = Integer.parseInt(p.sugar.trim());

                        if (sugar > 180)
                            diabetes++;
                        else if (bp > 140)
                            hypertension++;
                        else
                            normal++;
                    } catch (Exception ex) {
                        // skip invalid data
                    }
                }
                display.append("Total Patients: " + handler.patients.size() + "\n");
                display.append("Possible Diabetes Cases: " + diabetes + "\n");
                display.append("Possible Hypertension Cases: " + hypertension + "\n");
                display.append("Normal Patients: " + normal + "\n");
                break;

            case "Predict Disease":
                new PredictDiseaseFrame(display);
                break;
        }
    }
}

class AddPatientFrame extends Frame implements ActionListener {
    TextField id, name, age, bp, sugar, disease;
    Button save;
    DataHandler handler;
    TextArea display;

    AddPatientFrame(DataHandler h, TextArea d) {
        handler = h;
        display = d;

        setTitle("Add New Patient");
        setSize(400, 350);
        setLayout(new GridLayout(7, 2, 5, 5));

        add(new Label("Patient ID:")); id = new TextField(); add(id);
        add(new Label("Name:")); name = new TextField(); add(name);
        add(new Label("Age:")); age = new TextField(); add(age);
        add(new Label("BP:")); bp = new TextField(); add(bp);
        add(new Label("Sugar Level:")); sugar = new TextField(); add(sugar);
        add(new Label("Disease:")); disease = new TextField(); add(disease);

        save = new Button("Save");
        add(save);
        save.addActionListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        Patient p = new Patient(id.getText(), name.getText(), age.getText(), bp.getText(), sugar.getText(), disease.getText());
        handler.patients.add(p);
        handler.saveData();
        display.setText("Patient Added Successfully!\n" + p.toString());
        dispose();
    }
}

class SearchPatientFrame extends Frame implements ActionListener {
    TextField idField;
    Button search;
    DataHandler handler;
    TextArea display;

    SearchPatientFrame(DataHandler h, TextArea d) {
        handler = h;
        display = d;

        setTitle("Search Patient");
        setSize(300, 150);
        setLayout(new FlowLayout());

        add(new Label("Enter Patient ID:"));
        idField = new TextField(15);
        add(idField);

        search = new Button("Search");
        add(search);
        search.addActionListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String id = idField.getText();
        Patient p = handler.searchById(id);
        if (p != null)
            display.setText("Patient Found:\n" + p.toString());
        else
            display.setText("Patient not found!");
        dispose();
    }
}

class DeletePatientFrame extends Frame implements ActionListener {
    TextField idField;
    Button delete;
    DataHandler handler;
    TextArea display;

    DeletePatientFrame(DataHandler h, TextArea d) {
        handler = h;
        display = d;

        setTitle("Delete Patient");
        setSize(300, 150);
        setLayout(new FlowLayout());

        add(new Label("Enter Patient ID:"));
        idField = new TextField(15);
        add(idField);

        delete = new Button("Delete");
        add(delete);
        delete.addActionListener(this);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String id = idField.getText();
        boolean deleted = handler.deleteById(id);
        if (deleted)
            display.setText("Patient deleted successfully!");
        else
            display.setText("No patient found with that ID.");
        dispose();
    }
}

class PredictDiseaseFrame extends Frame implements ActionListener {

    Checkbox fever, cough, fatigue;
    TextField bpField, sugarField, ageField;
    Button predict;
    TextArea display;

    PredictDiseaseFrame(TextArea d) {
        display = d;

        setTitle("Disease Predictor");
        setSize(400, 350);
        setLayout(new GridLayout(8, 2, 5, 5));   // Clean 2-column layout

        // ---- Form Fields ----
        add(new Label("Age:"));
        ageField = new TextField();
        add(ageField);

        add(new Label("Blood Pressure (BP):"));
        bpField = new TextField();
        add(bpField);

        add(new Label("Sugar Level:"));
        sugarField = new TextField();
        add(sugarField);

        // ---- Symptoms ----
        add(new Label("Select Symptoms:"));
        add(new Label("")); // empty placeholder to align layout

        fever = new Checkbox("Fever");
        cough = new Checkbox("Cough");
        fatigue = new Checkbox("Fatigue");

        add(fever);
        add(cough);
        add(fatigue);
        add(new Label("")); // alignment fix

        // ---- Predict Button ----
        predict = new Button("Predict Disease");
        predict.addActionListener(this);
        add(predict);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            int bp = Integer.parseInt(bpField.getText().trim());
            int sugar = Integer.parseInt(sugarField.getText().trim());
            int age = Integer.parseInt(ageField.getText().trim());

            boolean f = fever.getState();
            boolean c = cough.getState();
            boolean fa = fatigue.getState();

            String result = DiseasePredictor.predict(bp, sugar, age, f, c, fa);

            display.setText("Predicted Result:\n" + result);

        } catch (Exception ex) {
            display.setText("Invalid Input! Please enter valid BP, Sugar, and Age.");
        }

        dispose();
    }
}

class DiseasePredictor {

    public static String predict(int bp, int sugar, int age, boolean fever, boolean cough, boolean fatigue) {

        int viralScore = 0;
        int diabetesScore = 0;
        int hypertensionScore = 0;
        int infectionScore = 0;

        // Viral infection rules
        if (fever) viralScore += 2;
        if (cough) viralScore += 2;

        // Diabetes rules
        if (sugar > 180) diabetesScore += 3;
        if (fatigue) diabetesScore += 1;
        if (age > 40 && sugar > 150) diabetesScore += 2;

        // Hypertension rules
        if (bp > 140) hypertensionScore += 3;
        if (age > 45 && bp > 135) hypertensionScore += 2;

        // General infection rules
        if (fever && fatigue) infectionScore += 2;

        // Select highest score
        int maxScore = Math.max(
                Math.max(viralScore, diabetesScore),
                Math.max(hypertensionScore, infectionScore)
        );

        if (maxScore == 0)
            return "No significant disease pattern detected.";

        if (maxScore == viralScore)
            return "High chance of Viral Infection based on symptoms.";

        if (maxScore == diabetesScore)
            return "High chance of Diabetes due to sugar levels and symptoms.";

        if (maxScore == hypertensionScore)
            return "High chance of Hypertension due to blood pressure indicators.";

        return "Possible General Infection.";
    }
}


public class MedicalInvantory {
    public static void main(String[] args) {
        new LoginFrame();
    }
}
